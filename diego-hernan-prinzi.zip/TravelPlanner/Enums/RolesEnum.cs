﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TravelPlanner.Enums
{
    public enum RolesEnum
    {
        Administrator,
        Manager,
        User
    }
}