﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Client.Utilities
{
    public interface ITokenHelper
    {
        string GetAuthenticationToken();
    }
}
