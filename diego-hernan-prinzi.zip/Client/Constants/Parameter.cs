﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Client.Constants
{
    public class Parameter
    {
        public static string TokenParameter = "token";
        public static string ExpirationDateParameter = "expirationDate";

    }
}